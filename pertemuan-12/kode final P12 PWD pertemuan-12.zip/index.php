<?php
session_start(); # P12
require_once("fungsi.php");
require_once("koneksi.php"); # P11

// P11: Mengambil data kontak dari basis data menggunakan operasi READ.
$sql = "SELECT * FROM tbl_kontak_nim";
$hasil = mysqli_query($koneksi, $sql);

// P11: Memeriksa keberhasilan kueri SELECT.
if (!$hasil) {
	die("Kueri SELECT gagal dijalankan.");
}

// P11: Mengambil hasil kueri sebagai larik asosiatif.
$dataKontak = [];
while ($baris = mysqli_fetch_assoc($hasil)) {
	$dataKontak[] = $baris;
}

// P11: Pengujian sementara hasil pengambilan data.
/* echo "<pre>";
var_dump($dataKontak);
echo "</pre>"; */



// P12: Mengambil dan memvalidasi data formulir.
$errors = [];
if ($_SERVER["REQUEST_METHOD"] === "POST") {

	// Mengambil data teks dari formulir.
	$nama = is_string($_POST["nama"] ?? null)
		? trim($_POST["nama"])
		: "";

	$email = is_string($_POST["email"] ?? null)
		? trim($_POST["email"])
		: "";

	$semesterForm = is_string($_POST["semester"] ?? null)
		? trim($_POST["semester"])
		: "";

	$tanggal = is_string($_POST["tanggal"] ?? null)
		? trim($_POST["tanggal"])
		: "";

	$jenisPesan = is_string($_POST["jenis_pesan"] ?? null)
		? trim($_POST["jenis_pesan"])
		: "";

	$prodi = is_string($_POST["prodi"] ?? null)
		? trim($_POST["prodi"])
		: "";

	$pesan = is_string($_POST["pesan"] ?? null)
		? trim($_POST["pesan"])
		: "";

	// Mengambil data checkbox.
	$minatInput = $_POST["minat"] ?? [];
	$minatValid = [];

	if (is_array($minatInput)) {
		foreach ($minatInput as $pilihan) {
			if (is_string($pilihan) && in_array($pilihan, ["HTML", "CSS"], true)) {
				$minatValid[] = $pilihan;
			}
		}
	}

	// Validasi nama.
	if (strlen($nama) < 3 || strlen($nama) > 50) {
		$errors[] = "Nama harus diisi 3 sampai 50 karakter.";
	}

	// Validasi email.
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$errors[] = "Alamat email tidak valid.";
	}

	// Validasi semester.
	$semesterValid = filter_var($semesterForm, FILTER_VALIDATE_INT);

	if ($semesterValid === false || $semesterValid < 1 || $semesterValid > 14) {
		$errors[] = "Semester harus berupa angka 1 sampai 14.";
	}

	// Validasi tanggal.
	$tanggalValid = false;

	if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
		$bagianTanggal = explode("-", $tanggal);

		$tanggalValid = checkdate(
			(int) $bagianTanggal[1],
			(int) $bagianTanggal[2],
			(int) $bagianTanggal[0]
		);
	}

	if (!$tanggalValid) {
		$errors[] = "Tanggal kunjungan tidak valid.";
	}

	// Validasi jenis pesan.
	if (!in_array($jenisPesan, ["pertanyaan", "saran"], true)) {
		$errors[] = "Jenis pesan tidak valid.";
	}

	// Validasi topik yang diminati.
	if (count($minatValid) === 0) {
		$errors[] = "Pilih minimal satu topik yang diminati.";
	}

	// Validasi program studi.
	if (!in_array($prodi, ["SI", "TI"], true)) {
		$errors[] = "Program studi tidak valid.";
	}

	// Validasi pesan.
	if ($pesan === "" || strlen($pesan) > 300) {
		$errors[] = "Pesan harus diisi dan maksimal 300 karakter.";
	}

	// Menyimpan input untuk ditampilkan kembali jika validasi gagal.
	$oldInput = [
		"nama" => $nama,
		"email" => $email,
		"semester" => $semesterForm,
		"tanggal" => $tanggal,
		"jenis_pesan" => $jenisPesan,
		"minat" => $minatValid,
		"prodi" => $prodi,
		"pesan" => $pesan
	];

	if (count($errors) > 0) {
		// Menyimpan pesan kesalahan dan input lama ke session.
		$_SESSION["form_errors"] = $errors;
		$_SESSION["old_input"] = $oldInput;
		unset($_SESSION["status_validasi"]);
	} else {
		// Menggabungkan pilihan minat menjadi satu teks.
		$minat = implode(", ", $minatValid);

		// Menyiapkan kueri INSERT.
		$sqlInsert = "INSERT INTO tbl_kontak_nim
                  (nama, email, semester, tanggal, jenis_pesan, minat, prodi, pesan)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

		$stmt = mysqli_prepare($koneksi, $sqlInsert);

		if ($stmt) {
			// Mengikat nilai ke parameter kueri.
			mysqli_stmt_bind_param(
				$stmt,
				"ssisssss",
				$nama,
				$email,
				$semesterValid,
				$tanggal,
				$jenisPesan,
				$minat,
				$prodi,
				$pesan
			);

			// Menjalankan kueri INSERT.
			if (mysqli_stmt_execute($stmt)) {
				$_SESSION["status_validasi"] =
					"Data berhasil disimpan ke database.";

				unset($_SESSION["form_errors"]);
				unset($_SESSION["old_input"]);
			} else {
				$_SESSION["form_errors"] = [
					"Data gagal disimpan ke database."
				];

				$_SESSION["old_input"] = $oldInput;
				unset($_SESSION["status_validasi"]);
			}

			mysqli_stmt_close($stmt);
		} else {
			$_SESSION["form_errors"] = [
				"Kueri penyimpanan data gagal disiapkan."
			];

			$_SESSION["old_input"] = $oldInput;
			unset($_SESSION["status_validasi"]);
		}
	}

	// Mengarahkan kembali browser ke halaman GET.
	header("Location: index.php#contact");
	exit;
}

// P12: Mengambil pesan sementara dari session setelah redirect.
$errors = $_SESSION["form_errors"] ?? [];
$statusValidasi = $_SESSION["status_validasi"] ?? "";
$oldInput = $_SESSION["old_input"] ?? [];

// Menghapus data sementara agar hanya ditampilkan satu kali.
unset($_SESSION["form_errors"]);
unset($_SESSION["status_validasi"]);
unset($_SESSION["old_input"]);



// P6: PHP dasar dan pemrograman sisi peladen
// Bagian 1: Variabel dan konstanta
$nim = "0344300002";
$namaMahasiswa = "Cantika Putih";
$programStudi = "SI";
$tahunAkademik = "2026/2027";
$semester = 4;
$ipk = 3.75;
$statusAktif = true;
$catatanTambahan = null;

const NAMA_MATA_KULIAH = "Pemrograman Web Dasar";
const PROFIL_GITHUB = "satpamal";

// Bagian 2: Operator
$batasSemester = 8;
$sisaSemester = $batasSemester - $semester;
$semesterValid = $semester >= 1 && $semester <= $batasSemester;
$statusSemester = ($semesterValid && $statusAktif) ? "Sesuai rentang" : "Perlu diperiksa";

// Bagian 3: Percabangan if-elseif-else
if ($semester < 3) {
	$keteranganSemester = "Semester awal";
} elseif ($semester <= 6) {
	$keteranganSemester = "Semester menengah";
} else {
	$keteranganSemester = "Semester akhir";
}

$namaProdi = ($programStudi == "SI") ? "Sistem Informasi" : (($programStudi == "TI") ? "Teknik Informatika" : "Lainnya");

// Bagian 4: Percabangan switch-case-default
switch ($programStudi) {
	case "SI":
		$fokusProgramStudi = "Sistem informasi dan proses bisnis";
		break;
	case "TI":
		$fokusProgramStudi = "Komputasi dan pengembangan perangkat lunak";
		break;
	default:
		$fokusProgramStudi = "Belum ditentukan";
}

// P9: Larik terindeks untuk menyimpan teknologi web yang dipelajari.
$teknologiWeb = ["HTML", "CSS", "JavaScript", "PHP", "MySQL"];
?>
<!doctype html>
<html lang="id">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Profil Mahasiswa</title>
	<link rel="stylesheet" href="style.css" />
</head>

<body>
	<header>
		<div class="header-top">
			<h1>Profil Mahasiswa</h1>

			<button
				class="nav-toggle"
				id="navToggle"
				type="button"
				aria-label="Buka navigasi"
				aria-controls="navMenu"
				aria-expanded="false">
				&#9776;
			</button>
		</div>

		<nav>
			<ul id="navMenu">
				<li><a href="#home">Beranda</a></li>
				<li><a href="#about">Tentang</a></li>
				<li><a href="#contact">Kontak</a></li>
			</ul>
		</nav>
	</header>

	<main>
		<section id="home">
			<h2>Selamat Datang</h2>
			<p>Halo, saya <?= tebal($namaMahasiswa); ?>. Saya sedang mempelajari matakuliah <strong><?= bersihkan(NAMA_MATA_KULIAH); ?></strong> pada tahun akademik <?= bersihkan($tahunAkademik); ?>.</p>

			<img src="img/foto-profil.jpg" alt="Foto profil Nama Mahasiswa" />
		</section>

		<section id="about">
			<h2>Tentang Saya</h2>

			<article>
				<h3>Profil Singkat</h3>
				<p>Program Studi: <?= bersihkan($namaProdi . " (" . $programStudi . ")"); ?></p>
				<p>Fokus program studi: <?= bersihkan($fokusProgramStudi); ?></p>
				<p>Status mahasiswa: <?= $statusAktif ? "Aktif" : "Tidak aktif"; ?></p>
				<p>Semester: <?= bersihkan($semester . " (" . $keteranganSemester . ")"); ?></p>
				<p>Sisa semester hingga batas: <?= bersihkan($sisaSemester); ?></p>
				<p>Pemeriksaan rentang semester: <?= bersihkan($statusSemester); ?></p>
				<p>IPK: <?= number_format($ipk, 2, ',', '.'); ?></p>
				<p>Catatan tambahan: <?= $catatanTambahan === null ? "Belum ada" : bersihkan($catatanTambahan); ?></p>

				<h3>Target Belajar (Perulangan for)</h3>
				<ol>
					<?php
					// Perulangan for tanpa larik; materi larik dibahas pada P9.
					for ($i = 1; $i <= 5; $i++) {
						echo "<li>Target belajar ke-" . $i . ": ";
						switch ($i) {
							case 1:
								echo "Memahami sintaks dasar PHP.";
								break;
							case 2:
								echo "Menggunakan variabel dan konstanta.";
								break;
							case 3:
								echo "Menerapkan operator dan percabangan.";
								break;
							case 4:
								echo "Menggunakan perulangan for dan while.";
								break;
							default:
								echo "Belum dipetakan";
								break;
						}
						echo "</li>";
					}
					?>
				</ol>

				<!-- P9: contoh penggunaan array terindeks -->
				<h3>Teknologi Web yang Dipelajari</h3>

				<p>
					Teknologi pertama yang dipelajari:
					<?= bersihkan($teknologiWeb[0]); ?>
				</p>

				<p>Daftar teknologi yang dipelajari:</p>

				<ul>
					<?php foreach ($teknologiWeb as $teknologi): ?>
						<li><?= bersihkan($teknologi); ?></li>
					<?php endforeach; ?>
				</ul>

				<h3>Semester (Perulangan while):</h3>
				<ol>
					<?php
					$nomorSemester = 1;
					while ($nomorSemester <= 3) {
						echo "<li>Semester " . $nomorSemester . "</li>";
						$nomorSemester++;
					}
					?>
				</ol>
			</article>
		</section>

		<section id="contact">
			<h2>Kontak</h2>

			<p>
				Kunjungi
				<a target="_blank" href="https://github.com/<?= bersihkan(PROFIL_GITHUB); ?>">profil GitHub saya</a>.
			</p>



			<?php if (count($errors) > 0): ?>
				<ul class="form-feedback-error">
					<?php foreach ($errors as $error): ?>
						<li><?= bersihkan($error); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php elseif ($statusValidasi !== ""): ?>
				<p class="form-feedback-success">
					<?= bersihkan($statusValidasi); ?>
				</p>
			<?php endif; ?>


			<form id="contactForm" class="js-contact-form" data-validation="contact" action="index.php" method="post" novalidate>
				<p class="form-feedback" data-form-feedback aria-live="polite"></p>

				<div class="form-group">
					<label for="nama">Nama Lengkap</label><br />
					<input class="input-form" type="text" id="nama" name="nama" placeholder="Masukkan nama lengkap"
						minlength="3" maxlength="50" required
						value="<?= htmlspecialchars($oldInput["nama"] ?? "", ENT_QUOTES, "UTF-8") ?>" />
				</div>

				<div class="form-group">
					<label for="email">Email</label><br />
					<input class="input-form" type="email" id="email" name="email" placeholder="nama@email.com" required
						value="<?= htmlspecialchars($oldInput["email"] ?? "", ENT_QUOTES, "UTF-8") ?>" />
				</div>

				<div class="form-group">
					<label for="semester">Semester</label><br />
					<input class="input-form" type="number" id="semester" name="semester" min="1" max="14" required
						value="<?= htmlspecialchars($oldInput["semester"] ?? "", ENT_QUOTES, "UTF-8") ?>" />
				</div>

				<div class="form-group">
					<label for="tanggal">Tanggal Kunjungan</label><br />
					<input class="input-form" type="date" id="tanggal" name="tanggal" required
						value="<?= htmlspecialchars($oldInput["tanggal"] ?? "", ENT_QUOTES, "UTF-8") ?>" />
				</div>

				<div class="form-group">
					<p>Jenis Pesan</p>
					<input type="radio" id="pertanyaan" name="jenis_pesan" value="pertanyaan" required
						<?= ($oldInput["jenis_pesan"] ?? "") === "pertanyaan" ? "checked" : "" ?> />
					<label for="pertanyaan">Pertanyaan</label>
					<input type="radio" id="saran" name="jenis_pesan" value="saran"
						<?= ($oldInput["jenis_pesan"] ?? "") === "saran" ? "checked" : "" ?> />
					<label for="saran">Saran</label>
				</div>

				<div class="form-group">
					<p>Topik yang Diminati</p>
					<input type="checkbox" id="minat-html" name="minat[]" value="HTML"
						<?= in_array("HTML", $oldInput["minat"] ?? [], true) ? "checked" : "" ?> />
					<label for="minat-html">HTML</label>
					<input type="checkbox" id="minat-css" name="minat[]" value="CSS"
						<?= in_array("CSS", $oldInput["minat"] ?? [], true) ? "checked" : "" ?> />
					<label for="minat-css">CSS</label>
				</div>

				<div class="form-group">
					<label for="prodi">Program Studi</label><br />
					<select class="input-form" id="prodi" name="prodi" required>
						<option value="">-- Pilih Program Studi --</option>
						<option value="SI" <?= ($oldInput["prodi"] ?? "") === "SI" ? "selected" : "" ?>>Sistem Informasi</option>
						<option value="TI" <?= ($oldInput["prodi"] ?? "") === "TI" ? "selected" : "" ?>>Teknik Informatika</option>
					</select>
				</div>

				<div class="form-group">
					<label for="pesan">Pesan</label><br />
					<textarea class="input-form" id="pesan" name="pesan" maxlength="300" placeholder="Tulis pesan Anda" required><?= htmlspecialchars($oldInput["pesan"] ?? "", ENT_QUOTES, "UTF-8") ?></textarea>
				</div>

				<button type="submit">Kirim</button>
				<button type="reset">Batal</button>

			</form>

			<article id="hasilKontak" class="submission-result" aria-live="polite">
				<h3>Data Kontak dari Basis Data</h3>
				<?php if (count($dataKontak) > 0): ?>
					<!-- Perulangan foreach untuk menampilkan data kontak. -->
					<?php foreach ($dataKontak as $data): ?>
						<section>
							<!-- Data kontak ditampilkan di sini. -->
							<p><strong>ID:</strong> <?= bersihkan($data["id"]); ?></p>
							<p><strong>Nama:</strong> <?= bersihkan($data["nama"]); ?></p>
							<p><strong>Email:</strong> <?= bersihkan($data["email"]); ?></p>
							<p><strong>Semester:</strong> <?= bersihkan($data["semester"]); ?></p>
							<p><strong>Tanggal Kunjungan:</strong> <?= bersihkan($data["tanggal"]); ?></p>
							<p><strong>Jenis Pesan:</strong> <?= bersihkan($data["jenis_pesan"]); ?></p>
							<p><strong>Topik yang Diminati:</strong> <?= bersihkan($data["minat"]); ?></p>
							<p><strong>Program Studi:</strong> <?= bersihkan($data["prodi"]); ?></p>
							<p><strong>Pesan:</strong> <?= nl2br(bersihkan($data["pesan"])); ?></p>
						</section>
					<?php endforeach; ?>
				<?php else: ?>
					<p>Belum ada data kontak yang tersimpan.</p>
				<?php endif; ?>
			</article>
		</section>

	</main>

	<footer>
		<p>&copy; <?= date("Y"); ?> <?= bersihkan($namaMahasiswa); ?> [<?= bersihkan($nim); ?>]</p>
	</footer>
	<script src="script.js"></script>
</body>

</html>