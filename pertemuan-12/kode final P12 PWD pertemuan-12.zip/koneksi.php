<?php
// Konfigurasi koneksi ke basis data MySQL.
$host = "localhost";
$user = "root";
$password = "";
$database = "db_pwd_nim";

// Membuat koneksi PHP dengan MySQL menggunakan MySQLi.
mysqli_report(MYSQLI_REPORT_OFF);

$koneksi = mysqli_connect($host, $user, $password, $database);

// Memeriksa keberhasilan koneksi.
if (!$koneksi) {
  die("Koneksi ke basis data gagal.");
}

// Mengatur charset koneksi ke UTF-8.
mysqli_set_charset($koneksi, "utf8mb4");
