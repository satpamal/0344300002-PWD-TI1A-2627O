# Pertemuan 3 - Formulir HTML dan CSS Dasar

## Baseline

- Menggunakan hasil P2 sebagai dasar pengembangan P3.
- Menyalin `index.html` dan `img/foto-profil.jpg` ke `pertemuan-03/`.

## Galat Awal

- Galat yang ditemukan: [tuliskan]
- Perbaikan yang dilakukan: [tuliskan]

## Implementasi Formulir

- Elemen form yang digunakan: [tuliskan]
- Tipe input yang digunakan: [tuliskan minimal 5]
- Atribut validasi yang digunakan: [tuliskan]

## Pengujian GET dan POST

- Hasil pengujian GET: [tuliskan]
- Contoh URL encoding yang ditemukan: [tuliskan]
- Hasil pengujian POST: [tuliskan]

## CSS Dasar

- Selector elemen: [tuliskan]
- Selector class: [tuliskan]
- Selector ID: [tuliskan]
- Properti CSS dasar yang digunakan: [tuliskan]

## Pengujian dan Perbaikan

- Galat tambahan yang ditemukan: [tuliskan]
- Perbaikan yang dilakukan: [tuliskan]

## GitHub Pages

URL: [tempel URL halaman P3]
